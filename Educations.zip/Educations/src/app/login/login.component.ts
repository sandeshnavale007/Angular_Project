import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: []
})
export class LoginComponent implements OnInit {
  logIn: FormGroup;

  constructor(private fb: FormBuilder, private router: Router,private _loginService: LoginService) { }

  ngOnInit(){
    this.logIn=this.fb.group({
      username:[''],
      password:['']
     });
  }
  onSubmit(data){
     this._loginService.logIn(data).subscribe((response) => {
       console.log(response.data.token);
       localStorage.setItem('token',response.data.token)
      this.router.navigate(['/employee']);
    })
  }
}
