import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor } from '@angular/common/http';
import { LoginService } from '../service/login.service';
import { nextTick } from 'process';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {

  constructor(private injextor :  Injector) { }
  intercept(req, next){
    let authService = this.injextor.get(LoginService)
    let tokeinitialize = req.clone({
        setHeaders:{
          Authorization: 'Bearer ${authService.getToken()}'
        }
    })
    return next.handle(tokeinitialize)
  }
}
