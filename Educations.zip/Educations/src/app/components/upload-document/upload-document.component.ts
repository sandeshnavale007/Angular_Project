import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-upload-document',
  templateUrl: './upload-document.component.html',
  styleUrls: ['./upload-document.component.css']
})
export class UploadDocumentComponent implements OnInit {
  uploadDocument: FormGroup;
  constructor(private fb: FormBuilder, private _empployeService: EmployeeService) { }

  ngOnInit(): void {
    this.uploadDocument = this.fb.group({
      id: [''],
      documentName:[''],
      documents:[''],
     });
  }
  onSubmit(data){
    this._empployeService.uploadDocument(data).subscribe((response) => {
    })
  }
}
