import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private _urls: string="http://localhost:8086/employee/login";

  constructor(private http : HttpClient) { }

  logIn(data):Observable<any>{
    return this.http.post(this._urls,data)
  }
  getToken(){
    return localStorage.getItem('token')
  }
  loggedIn(){
    console.log(localStorage.getItem('token'));
    return !!localStorage.getItem('token')
  }
}
