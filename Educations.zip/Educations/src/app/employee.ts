export interface IEmployee{
    id:number,
    fullName:string,
    salary:string,
    email:string,
    password:string
}