import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
public employees = [];
userPost: FormGroup;

  constructor(private fb: FormBuilder, private _employeeSerice : EmployeeService) { }

  ngOnInit() {
    this.getData();
    this.userPost = this.fb.group({
      id: [''],
      fullName:[''],
      email:[''],
      salary:[''],
      password:['']
     });
  }
  getData(){
    this._employeeSerice.getEmployees().subscribe(data =>this.employees=data );
  }
  onSubmit(data){
     this._employeeSerice.postEmployee(data).subscribe((response) => {
    },(error: HttpErrorResponse) => {
      this.getData();
    })
  }
  remove(id: number){
      this._employeeSerice.removeEmployee(id).subscribe((response) =>{
        this.getData();
    },(error: HttpErrorResponse) => {
      this.getData();
    })
  }
  edit(id:number){
    this._employeeSerice.editEmployee(id).subscribe(employees =>{
      console.log(employees.fullName);
      this.userPost.patchValue({
        id: employees.id,
        fullName:employees.fullName,
        email:employees.email,
        salary:employees.salary
       });
    })
  }
}
