import { Component, OnInit } from '@angular/core';
import { Router, Routes } from '@angular/router';
import { AuthGuard } from '../auth/auth.guard';
import { UploadDocumentComponent } from '../components/upload-document/upload-document.component';
import { EmployeeComponent } from '../employee/employee.component';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor( private router: Router) { }

  ngOnInit(): void {
  }
  
  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
}
}
